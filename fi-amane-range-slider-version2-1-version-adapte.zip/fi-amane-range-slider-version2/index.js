var range = document.getElementById('range');
var tooltip = document.getElementById('tooltip');
var colis = document.getElementById('colis');
var commission = document.getElementById('commission');
var total = document.getElementById('total');
var formuleAdapte = document.getElementById('formuleAdapte');
setValue = () => {
  const newValue = Number(
      ((range.value - range.min) * 100) / (range.max - range.min)
    ),
    newPosition = 16 - newValue * 0.32;

  tooltip.innerHTML = `<span id="inner-tooltip">${range.value}</span>`;
  tooltip.style.left = `calc(${newValue}% + (${newPosition}px))`;
  let innerTooltip = document.getElementById('inner-tooltip');
  colis.innerHTML = range.value;
  if (range.value < 400) {
    innerTooltip.style.backgroundColor = '#240046';
    commission.innerHTML = '0.30';
    total.innerHTML = (0.3 * range.value).toFixed(2) + ' $';
    formuleAdapte.innerHTML = 'Starter';
    total.style.color = '#ff8501';
    formuleAdapte.style.color = '#ff8501';
  } else {
    innerTooltip.style.backgroundColor = '#ff8501';
    commission.innerHTML = '0.35';
    total.innerHTML = (0.35 * range.value).toFixed(2) + ' $';
    formuleAdapte.innerHTML = 'Premium';
    total.style.color = '#240046';
    formuleAdapte.style.color = '#240046';
  }
  document.documentElement.style.setProperty(
    '--range-progress',
    `calc(${newValue}% + (${newPosition}px))`
  );
};
document.addEventListener('DOMContentLoaded', setValue);
range.addEventListener('input', setValue);
