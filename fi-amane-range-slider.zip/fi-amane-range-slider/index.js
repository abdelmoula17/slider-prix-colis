var slider = document.getElementById('myRange');
var colis = document.getElementById('colis');
var commission = document.getElementById('commission');
var total = document.getElementById('total');
colis.innerHTML = slider.value;

slider.oninput = function () {
  colis.innerHTML = this.value;
  commission.innerHTML = '0.3';
  if (this.value < 400) {
    commission.innerHTML = '0.30';
    total.innerHTML = (0.3 * this.value).toFixed(2) + ' $';
  } else {
    commission.innerHTML = '0.35';
    total.innerHTML = (0.35 * this.value).toFixed(2) + ' s$';
  }
};
